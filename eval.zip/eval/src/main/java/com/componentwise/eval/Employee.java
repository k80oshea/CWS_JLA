package com.componentwise.eval;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Employee {
    
    @Id
    @GeneratedValue
    private int id;
    private boolean managerFlag;
    @Size(min=1, max=64)
    private String name;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date dateHired;
    private boolean partTimerFlag; //the default value of primitive booleans is false
    
    //added the partTimerFlag to the constructor, set automatically to false (HR could change as needed along with managerFlag).
    //can assume all new employees may or may not be part time and all old employees were solely full time.
    public Employee() {
    	this.dateHired = new Date();
    	this.managerFlag = false;
    	this.partTimerFlag = false;
    }

	public int getID() {
		return id;
	}
	public boolean isManager() {
		return managerFlag;
	}
	public String getName() {
		return name;
	}
	public Date getDateHired() {
		return dateHired;
	}
	public boolean isPartTimer() {
		return partTimerFlag;
	}

}
