package com.componentwise.eval;

import java.util.ArrayList;

public class Parser {
	public String xmlToCheck;
    public void checkXML(String input) {
        xmlToCheck = input;
    }
    public Boolean parser(){
        int openCarrot = 0;
        int closeCarrot = 0;
        int openCarrotSlash = 0;

        //first the parser can run a basic check to see if all tags are closed and constructed properly
        for(int x=0; x<xmlToCheck.length(); x++) {
            if(xmlToCheck.charAt(x) == '<') {
                openCarrot++;
                if(xmlToCheck.charAt(x+1) == '/') {
                    openCarrotSlash++;
                }
                else if (Character.isLetter(xmlToCheck.charAt(x+1)) == false) {
                    return false; //xml is not wellformed
                }
            }
            if(xmlToCheck.charAt(x) == '>') {
                closeCarrot++;
            }
        }
        if(openCarrot != closeCarrot) {
            return false; //xml is not wellformed 
        }
        if(openCarrot/2 != openCarrotSlash) {
            return false; //xml is not wellformed
        }

        //then it will check to see if all tags are wellformed
        ArrayList<String> openTags = new ArrayList<String>();
        ArrayList<String> closeTags = new ArrayList<String>(); 
        String tag = "";       
        for(int y=0; y<xmlToCheck.length(); y++) {
            if(xmlToCheck.charAt(y) == '<') {
                if(xmlToCheck.charAt(y+1) == '/') {
                    while (xmlToCheck.charAt(y) != '>') {
                        tag += xmlToCheck.charAt(y); 
                        y++;                      
                    }
                    closeTags.add(tag);
                    tag = "";
                }
                else {
                    while (xmlToCheck.charAt(y) != '>') {
                        tag += xmlToCheck.charAt(y); 
                        y++;                      
                    }
                    openTags.add(tag);
                    tag = "";
                }
            }
        }
        // System.out.println(openTags);
        // System.out.println(closeTags);
        if(openTags.size() != closeTags.size()) {
            return false; //xml is not wellformed, not all tags are closed
        }
        for(int z = 0; z<openTags.size(); z++) {
            for(int i=closeTags.size()-1; i>=0; i--) {
                if(openTags.get(z) != closeTags.get(i)) {
                    return false; //xml is not wellformed, openTags and closeTags should be direct inverses of each other
                }
            }
        }

        //if code passes all above tests, xml is well formed and can return true
        return true;
    }

}
