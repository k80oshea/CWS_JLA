package com.componentwise.eval;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import org.junit.Before;
import org.junit.Test;

public class TestCase {

	String name = "Katie O'Shea";
	String userid = "KOSHEA";
	UserKey uk = new UserKey(name, userid);
	
	@SuppressWarnings("unused")
	@Before
	public void testUserKey() throws Exception{
		UserKey userkey = new UserKey("Katie O'Shea", "KOSHEA");
	}
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@Test
	public void testHashCode() {
		System.out.println("hashCode");
		int hc = ("Katie O'Shea").hashCode() * ("KOSHEA").hashCode();
		assertEquals(hc, uk.hashCode());
	}
	@Test
	public void testEquals() {
		System.out.println("equals");
		UserKey testK = new UserKey("Katie O'Shea", "KOSHEA");
		assertTrue(testK.equals(uk));		
	}
	@Test
	public void testGetName() {
		System.out.println("getName");
		assertEquals("Katie O'Shea", uk.getName());
	}
	@Test
	public void testGetUserID() {
		System.out.println("getUserID");
		assertEquals("KOSHEA", uk.getUserID());
	}
	@Test
	public void testSerializable() {
		System.out.println("serializable");
		try{
			new ObjectOutputStream(new ByteArrayOutputStream()).writeObject(uk);
		}
		catch(Exception e){
			fail("Should not have thrown any exceptions");
		}
	}
}
