package com.componentwise.eval;
import javax.servlet.http.HttpSession;

public class UserKey {
	private String name;
    private String userid;
    public HttpSession session;
    
    @Override
//    override .hashCode() to use name and userid and satisfy null cases
    public int hashCode() {
    	if(name == null || userid == null) return 0;
    	else return (int) name.hashCode() * userid.hashCode();
    }
    
    @Override
//    override .equals() to check against hashCode duplicates
    public boolean equals(Object obj) {
	    if(obj == null || this.hashCode() != obj.hashCode()) {
	    	return false;
	    }
	    else return true;
    }
    
    public UserKey(String name, String userid) {
        this.name = name;
        this.userid = userid;
    }
    public String getName() {
        return name;
    }
    public String getUserID() {
        return userid;
    }

}
